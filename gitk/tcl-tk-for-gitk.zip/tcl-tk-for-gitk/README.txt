================================================================================
   tcl-tk for gitk
================================================================================

■概要

最新のcygwin setup.exeを使ってgitk、tcl-tkをインストールすると、
gitkが使えない。
なんかよくわからないけどtcl-tkがおかしいのが原因。
なので、ちゃんと動いてた頃のtcl-tkを入れてしまえ、という試み。


■準備

cygwinのsetup.exeでtcl-tkをUninstallしておく。
gitkは最新でOK。


■設置

以下の3ファイルは/usr/bin以下に設置。

- wish84.exe
- tcl84.dll
- tk84.dll

そして、/usr/bin/wish.exeから/usr/bin/wish84.exeに
シンボリックリンクを貼る。

ln -s /usr/bin/wish84.exe /usr/bin/wish.exe


以下の2ファイルは/usr/share以下に設置し、解答。

- tcl8.4.tar.gz
- tk8.4.tar.gz

tar xzf tcl8.4.tar.gz
tar xzf tk8.4.tar.gz
